# Earn App – Vercel deploy
1. Create a Postgres DB (Vercel Storage → Neon, or any Postgres). Copy its connection string.
2. Import this folder (GitHub repo or `vercel` CLI) to Vercel.
3. Add Environment Variables: DATABASE_URL, ADMIN_USERNAME, ADMIN_PASSWORD, SESSION_SECRET (long random), PUBLIC_SITE_URL (https://your-domain), NODE_ENV=production
4. Deploy. Tables are created automatically on the first request. Admin: /admin
Logos: put bkash.png / nagad.png / rocket.png in /public (placeholders not included yet).
