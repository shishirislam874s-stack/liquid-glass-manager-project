require('pg').types.setTypeParser(1082,v=>v);
const express=require('express'),{Pool}=require('pg'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),multer=require('multer'),cp=require('cookie-parser'),crypto=require('crypto');
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:false},max:3});
const SECRET=process.env.SESSION_SECRET||'';const PROD=process.env.NODE_ENV==='production';
const up=multer({storage:multer.memoryStorage(),limits:{fileSize:2e6},fileFilter:(r,f,cb)=>cb(null,/^image\/(png|jpe?g|webp)$/.test(f.mimetype))});
const app=express();app.use(express.json({limit:'50kb'}));app.use(cp());
const D={payment_number_bkash:'01604606880',payment_number_nagad:'01604606880',payment_number_rocket:'01604606880',fee_A:500,fee_B:1000,fee_C:1500,cap_A:50,cap_B:100,cap_C:150,min_withdraw:100,ref_join:1,ref_active:100,work_days:5,w1_days:2,w2_days:3,w3_days:4,team_size:20,t1_bonus:10,t2_bonus:20,t3_bonus:30,watch_seconds:15};
const today=()=>new Date(Date.now()+6*36e5).toISOString().slice(0,10);
const addDays=(d,n)=>{const x=new Date(d+'T00:00:00Z');x.setUTCDate(x.getUTCDate()+n);return x.toISOString().slice(0,10)};
let ready;const init=()=>ready||(ready=(async()=>{await pool.query(`
create table if not exists users(id serial primary key,name text,phone text unique,pass text,cat text,balance int default 0,work_until date,referred_by int,blocked bool default false,activated_at timestamptz,created timestamptz default now());
create table if not exists settings(k text primary key,v text);
create table if not exists videos(id serial primary key,title text,link text,reward int);
create table if not exists reqs(id serial primary key,user_id int,type text,status text default 'pending',cat text,method text,txid text,video_id int,amount int default 0,number text,img bytea,note text,created timestamptz default now());
create unique index if not exists u_tx on reqs(txid) where type='act';
create unique index if not exists u_vid on reqs(user_id,video_id) where type='vid' and status in('pending','approved');
create table if not exists watch(user_id int,video_id int,started_at timestamptz,primary key(user_id,video_id));
create table if not exists daily(user_id int,d date,amount int default 0,primary key(user_id,d));
create table if not exists ledger(id serial primary key,user_id int,kind text,amount int,status text,note text,created timestamptz default now());
create table if not exists notes(id serial primary key,user_id int,msg text,created timestamptz default now());
create table if not exists bcast(id serial primary key,msg text,created timestamptz default now());`)})());
const S=async(c=pool)=>{const o={...D};(await c.query('select * from settings')).rows.forEach(r=>o[r.k]=isNaN(r.v)?r.v:+r.v);return o};
const wrap=f=>(q,s)=>init().then(()=>f(q,s)).catch(e=>{console.error(e.message);s.status(e.status||500).json({error:e.msg||'server'})});
const E=(status,msg)=>Object.assign(new Error(msg),{status,msg});
const tx=async f=>{const c=await pool.connect();try{await c.query('begin');const r=await f(c);await c.query('commit');return r}catch(e){await c.query('rollback');throw e}finally{c.release()}};
const ck=(s,n,t)=>s.cookie(n,jwt.sign(t,SECRET,{expiresIn:n==='a'?'30m':'30d'}),{httpOnly:true,secure:PROD,sameSite:'lax'});
const auth=wrap2=>async(q,s,n)=>{try{const t=jwt.verify(q.cookies.u,SECRET);const r=await pool.query('select * from users where id=$1',[t.id]);if(!r.rows[0]||r.rows[0].blocked)throw 0;q.user=r.rows[0];n()}catch{s.status(401).json({error:'auth'})}};
const adm=(q,s,n)=>{try{if(!jwt.verify(q.cookies.a,SECRET).admin)throw 0;n()}catch{s.status(401).json({error:'auth'})}};
const note=(c,u,m)=>c.query('insert into notes(user_id,msg) values($1,$2)',[u,m]);
const led=(c,u,k,a,st,n)=>c.query('insert into ledger(user_id,kind,amount,status,note) values($1,$2,$3,$4,$5)',[u,k,a,st,n]);
const pay=async(c,u,k,a,n)=>{await c.query('update users set balance=balance+$2 where id=$1',[u,a]);await led(c,u,k,a,'approved',n)};
const U=auth();
// ---- user auth
app.post('/api/register',wrap(async(q,s)=>{const{name,phone,password,ref}=q.body;if(!name||!/^01\d{9}$/.test(phone||'')||(password||'').length<6)throw E(400,'invalid');const st=await S();
 const id=await tx(async c=>{let rb=null;if(+ref){const r=await c.query('select id from users where id=$1',[+ref]);rb=r.rows[0]?.id||null}
 const r=await c.query('insert into users(name,phone,pass,referred_by) values($1,$2,$3,$4) returning id',[name.slice(0,60),phone,bcrypt.hashSync(password,10),rb]);
 if(rb){await pay(c,rb,'referral_join',st.ref_join,'join');await note(c,rb,'New referral joined / নতুন রেফারেল জয়েন করেছে')}return r.rows[0].id}).catch(e=>{throw e.code==='23505'?E(409,'phone_exists'):e});
 ck(s,'u',{id});s.json({ok:1})}));
app.post('/api/login',wrap(async(q,s)=>{const r=await pool.query('select * from users where phone=$1',[q.body.phone]);const u=r.rows[0];if(!u||!bcrypt.compareSync(q.body.password||'',u.pass)||u.blocked)throw E(401,'bad_login');ck(s,'u',{id:u.id});s.json({ok:1})}));
app.post('/api/logout',(q,s)=>{s.clearCookie('u');s.clearCookie('a');s.set('Cache-Control','no-store').json({ok:1})});
app.get('/api/me',U,wrap(async(q,s)=>{const u=q.user,st=await S(),t=today();const d=await pool.query('select amount from daily where user_id=$1 and d=$2',[u.id,t]);
 const rf=await pool.query("select count(*) n,count(cat) a from users where referred_by=$1",[u.id]);const nt=await pool.query('select msg from notes where user_id=$1 order by id desc limit 10',[u.id]);const bc=await pool.query('select msg from bcast order by id desc limit 1');
 s.json({id:u.id,name:u.name,cat:u.cat,balance:u.balance,work_until:u.work_until,
 workOpen:!!u.cat&&!!u.work_until&&t<=u.work_until,
 earned:d.rows[0]?.amount||0,cap:u.cat?st['cap_'+u.cat]:0,refs:+rf.rows[0].n,activeRefs:+rf.rows[0].a,leader:+rf.rows[0].a>=st.team_size,notes:nt.rows,banner:bc.rows[0]?.msg,settings:st,site:process.env.PUBLIC_SITE_URL||''})}));
const needActive=(q,s,n)=>q.user.cat?n():s.status(403).json({error:'locked'});
// ---- activation
app.post('/api/activate',U,wrap(async(q,s)=>{const{cat,method,txid}=q.body;const st=await S();if(!['A','B','C'].includes(cat)||!['bkash','nagad','rocket'].includes(method)||!/^[A-Za-z0-9]{6,20}$/.test(txid||''))throw E(400,'invalid');
 await pool.query("insert into reqs(user_id,type,cat,method,txid,amount) values($1,'act',$2,$3,$4,$5)",[q.user.id,cat,method,txid.toUpperCase(),st['fee_'+cat]]).catch(e=>{throw e.code==='23505'?E(409,'dup_txid'):e});
 await led(pool,q.user.id,'activation',-0,'pending','Category '+cat);s.json({ok:1})}));
// ---- videos
app.get('/api/videos',U,needActive,wrap(async(q,s)=>{const r=await pool.query("select v.id,v.title,v.link,v.reward from videos v where not exists(select 1 from reqs r where r.user_id=$1 and r.video_id=v.id and r.type='vid' and r.status in('pending','approved')) order by v.id",[q.user.id]);s.json(r.rows)}));
app.post('/api/watch/:id',U,needActive,wrap(async(q,s)=>{await pool.query('insert into watch values($1,$2,now()) on conflict(user_id,video_id) do update set started_at=case when watch.started_at<now()-interval \'30 minutes\' then now() else watch.started_at end',[q.user.id,+q.params.id]);const r=await pool.query('select started_at from watch where user_id=$1 and video_id=$2',[q.user.id,+q.params.id]);const st=await S();s.json({left:Math.max(0,st.watch_seconds-(Date.now()-r.rows[0].started_at)/1000)})}));
const openWork=async(c,u)=>{const r=await c.query('select work_until from users where id=$1',[u]);return !!r.rows[0].work_until&&today()<=r.rows[0].work_until};
app.post('/api/submit/:id',U,needActive,up.single('proof'),wrap(async(q,s)=>{if(!q.file)throw E(400,'image_required');const vid=+q.params.id,uid=q.user.id;const st=await S();
 await tx(async c=>{await c.query('select id from users where id=$1 for update',[uid]);if(!(await openWork(c,uid)))throw E(403,'work_locked');
 const v=(await c.query('select * from videos where id=$1',[vid])).rows[0];if(!v)throw E(404,'nf');
 const w=(await c.query('select started_at from watch where user_id=$1 and video_id=$2',[uid,vid])).rows[0];const age=w?(Date.now()-w.started_at)/1000:0;if(!w||age<st.watch_seconds||age>1800)throw E(403,'watch_time');
 const t=today();await c.query('insert into daily values($1,$2,0) on conflict do nothing',[uid,t]);const e=(await c.query('select amount from daily where user_id=$1 and d=$2 for update',[uid,t])).rows[0].amount;
 const p=(await c.query("select coalesce(sum(amount),0) n from reqs where user_id=$1 and type='vid' and status='pending'",[uid])).rows[0].n;if(+e+ +p>=st['cap_'+q.user.cat])throw E(403,'daily_limit');
 await c.query("insert into reqs(user_id,type,video_id,amount,img) values($1,'vid',$2,$3,$4)",[uid,vid,v.reward,q.file.buffer]);await led(c,uid,'video',v.reward,'pending',v.title)}).catch(e=>{throw e.code==='23505'?E(409,'already_submitted'):e});s.json({ok:1})}));
// ---- withdraw / history
app.post('/api/withdraw',U,needActive,wrap(async(q,s)=>{const{method,number}=q.body,a=Math.floor(+q.body.amount);const st=await S();if(!['bkash','nagad','rocket'].includes(method)||!/^01\d{9}$/.test(number||'')||!(a>=st.min_withdraw))throw E(400,'invalid');
 await tx(async c=>{const r=await c.query('update users set balance=balance-$2 where id=$1 and balance>=$2 returning id',[q.user.id,a]);if(!r.rows[0])throw E(400,'no_balance');await c.query("insert into reqs(user_id,type,method,number,amount) values($1,'wd',$2,$3,$4)",[q.user.id,method,number,a]);await led(c,q.user.id,'withdraw',-a,'pending',method)});s.json({ok:1})}));
app.get('/api/history',U,wrap(async(q,s)=>s.json((await pool.query("select kind,amount,status,note,to_char(created at time zone 'Asia/Dhaka','YYYY-MM-DD HH24:MI') at from ledger where user_id=$1 order by id desc limit 200",[q.user.id])).rows)));
app.get('/api/team',U,wrap(async(q,s)=>s.json({members:(await pool.query('select name,cat,(select count(*) from users x where x.referred_by=u.id) brought from users u where referred_by=$1',[q.user.id])).rows,bonus:(await pool.query("select coalesce(sum(amount),0) n from ledger where user_id=$1 and kind='team_bonus'",[q.user.id])).rows[0].n})));
// ---- admin
const fails={};app.post('/api/admin/login',wrap(async(q,s)=>{const ip=q.headers['x-forwarded-for']||'x',f=fails[ip]||(fails[ip]={n:0,t:0});if(f.t>Date.now())throw E(429,'locked');
 const h=x=>crypto.createHash('sha256').update(String(x)).digest();const ok=process.env.ADMIN_USERNAME&&crypto.timingSafeEqual(h(q.body.username),h(process.env.ADMIN_USERNAME))&crypto.timingSafeEqual(h(q.body.password),h(process.env.ADMIN_PASSWORD));
 if(!ok){if(++f.n>=5){f.t=Date.now()+3e5;f.n=0}throw E(401,'bad_login')}f.n=0;ck(s,'a',{admin:1});s.json({ok:1})}));
app.get('/api/admin/stats',adm,wrap(async(q,s)=>{const r=await pool.query("select (select count(*) from users) users,(select count(*) from users where cat is not null) active,(select count(*) from reqs where status='pending') pending,(select coalesce(sum(amount),0) from reqs where type='wd' and status='paid') paid");s.json(r.rows[0])}));
app.get('/api/admin/reqs',adm,wrap(async(q,s)=>{const t=q.query.type,st=q.query.status||'pending',off=+q.query.offset||0;const r=await pool.query("select r.id,r.status,r.cat,r.method,r.txid,r.number,r.amount,r.video_id,(img is not null) has_img,u.name,u.id uid,to_char(r.created at time zone 'Asia/Dhaka','YYYY-MM-DD HH24:MI') at from reqs r join users u on u.id=r.user_id where r.type=$1 and ($2='all' or r.status=$2) order by r.id desc limit 20 offset $3",[t,st,off]);
 const b=await pool.query("select type,count(*) n from reqs where status='pending' group by type");s.json({rows:r.rows,badges:Object.fromEntries(b.rows.map(x=>[x.type,+x.n]))})}));
app.get('/api/admin/img/:id',adm,wrap(async(q,s)=>{const r=await pool.query('select img from reqs where id=$1',[+q.params.id]);s.type('image/jpeg').send(r.rows[0]?.img)}));
app.post('/api/admin/reqs/:id/:act',adm,wrap(async(q,s)=>{const act=q.params.act;const st=await S();await tx(async c=>{const r=(await c.query("select * from reqs where id=$1 and status='pending' for update",[+q.params.id])).rows[0];if(!r)throw E(409,'done');const u=r.user_id;
 if(act==='reject'){await c.query("update reqs set status='rejected' where id=$1",[r.id]);if(r.type==='wd')await pay(c,u,'refund',r.amount,'withdraw refund');await c.query("update ledger set status='rejected' where id=(select max(id) from ledger where user_id=$1 and kind=$2 and status='pending')",[u,{act:'activation',vid:'video',wd:'withdraw'}[r.type]]);await note(c,u,'Request rejected / অনুরোধ বাতিল');return}
 if(r.type==='wd'){if(act!=='paid')throw E(400,'bad');await c.query("update reqs set status='paid' where id=$1",[r.id]);await c.query("update ledger set status='paid' where id=(select max(id) from ledger where user_id=$1 and kind='withdraw' and status='pending')",[u]);await note(c,u,'Withdraw paid / উইথড্র পেইড');return}
 if(act!=='approve')throw E(400,'bad');
 if(r.type==='vid'){const cat=(await c.query('select cat from users where id=$1',[u])).rows[0].cat;const t=today();await c.query('insert into daily values($1,$2,0) on conflict do nothing',[u,t]);const e=(await c.query('select amount from daily where user_id=$1 and d=$2 for update',[u,t])).rows[0].amount;
  const cr=Math.max(0,Math.min(r.amount,st['cap_'+cat]-e));await c.query('update daily set amount=amount+$3 where user_id=$1 and d=$2',[u,t,cr]);await c.query("update reqs set status='approved',amount=$2 where id=$1",[r.id,cr]);
  if(cr>0)await c.query('update users set balance=balance+$2 where id=$1',[u,cr]);await c.query("update ledger set status='approved',amount=$2 where id=(select max(id) from ledger where user_id=$1 and kind='video' and status='pending')",[u,cr]);await note(c,u,cr?'Work approved +'+cr+' / কাজ অনুমোদিত':'Daily limit reached / দৈনিক সীমা পূর্ণ');return}
 // activation
 const usr=(await c.query('select * from users where id=$1 for update',[u])).rows[0];const first=!usr.activated_at;
 await c.query("update reqs set status='approved' where id=$1",[r.id]);await c.query("update ledger set status='approved' where id=(select max(id) from ledger where user_id=$1 and kind='activation' and status='pending')",[u]);
 await c.query('update users set cat=$2,activated_at=coalesce(activated_at,now()),work_until=coalesce(work_until,$3) where id=$1',[u,r.cat,addDays(today(),st.work_days-1)]);await note(c,u,'ID activated / আইডি অ্যাক্টিভ');
 if(first&&usr.referred_by){const X=usr.referred_by,days=st[{A:'w1_days',B:'w2_days',C:'w3_days'}[r.cat]];await pay(c,X,'referral_active',st.ref_active,'activation bonus');
  const x=(await c.query('select work_until,referred_by from users where id=$1 for update',[X])).rows[0];const base=x.work_until&&today()<=x.work_until?x.work_until:today();
  await c.query('update users set work_until=$2 where id=$1',[X,addDays(base,days)]);await note(c,X,'Work window extended / কাজের সময় বেড়েছে');
  const L=x.referred_by;if(L){const l=(await c.query('select cat from users where id=$1',[L])).rows[0];const n=(await c.query('select count(*) n from users where referred_by=$1 and cat is not null',[L])).rows[0].n;
   if(l.cat&&+n>=st.team_size){const b=st[{A:'t1_bonus',B:'t2_bonus',C:'t3_bonus'}[r.cat]];await pay(c,L,'team_bonus',b,'team:'+X+'>'+u);await note(c,L,'Team bonus +'+b+' / টিম বোনাস')}}}
 });s.json({ok:1})}));
app.get('/api/admin/users',adm,wrap(async(q,s)=>s.json((await pool.query("select id,name,phone,cat,balance,work_until,blocked,(select count(*) from users x where x.referred_by=u.id and x.cat is not null) refs from users u where $1='' or name ilike '%'||$1||'%' or phone like '%'||$1||'%' or id::text=$1 order by id desc limit 50",[q.query.q||''])).rows)));
app.post('/api/admin/user/:id',adm,wrap(async(q,s)=>{const id=+q.params.id,{op,value}=q.body;await tx(async c=>{if(op==='balance'){const a=Math.trunc(+value);const r=await c.query('update users set balance=balance+$2 where id=$1 and balance+$2>=0 returning id',[id,a]);if(!r.rows[0]||!a)throw E(400,'invalid');await led(c,id,'admin_adjust',a,'approved','admin');await note(c,id,'Balance changed '+a+' / ব্যালেন্স পরিবর্তন')}
 else if(op==='cat'&&['A','B','C'].includes(value))await c.query('update users set cat=$2 where id=$1',[id,value]);else if(op==='block')await c.query('update users set blocked=not blocked where id=$1',[id]);else throw E(400,'bad')});s.json({ok:1})}));
app.get('/api/admin/videos',adm,wrap(async(q,s)=>s.json((await pool.query('select * from videos order by id desc')).rows)));
app.post('/api/admin/videos',adm,wrap(async(q,s)=>{const{id,title,link,reward}=q.body;if(!title||!/^https?:\/\//.test(link||'')||!(+reward>0))throw E(400,'invalid');if(id)await pool.query('update videos set title=$2,link=$3,reward=$4 where id=$1',[id,title,link,+reward]);else await pool.query('insert into videos(title,link,reward) values($1,$2,$3)',[title,link,+reward]);s.json({ok:1})}));
app.delete('/api/admin/videos/:id',adm,wrap(async(q,s)=>{await pool.query('delete from videos where id=$1',[+q.params.id]);s.json({ok:1})}));
app.get('/api/admin/settings',adm,wrap(async(q,s)=>s.json(await S())));
app.post('/api/admin/settings',adm,wrap(async(q,s)=>{for(const[k,v]of Object.entries(q.body))if(k in D)await pool.query('insert into settings values($1,$2) on conflict(k) do update set v=$2',[k,String(v)]);s.json({ok:1})}));
app.post('/api/admin/broadcast',adm,wrap(async(q,s)=>{await pool.query('insert into bcast(msg) values($1)',[String(q.body.msg).slice(0,300)]);s.json({ok:1})}));
app.get('/api/admin/team-bonuses',adm,wrap(async(q,s)=>s.json((await pool.query("select l.amount,l.note,u.name leader,u.id leader_id,to_char(l.created at time zone 'Asia/Dhaka','YYYY-MM-DD HH24:MI') at from ledger l join users u on u.id=l.user_id where l.kind='team_bonus' order by l.id desc limit 100")).rows)));
module.exports=app;
